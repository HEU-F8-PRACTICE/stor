#v0.1.0(2020.2.22~2021.2.23)
def debug(text):#用于调试
    print('debug:'+str(text))

def runone():
    #初始化
    print('初始化中...')
    import os,time
    no=['+',',']#需要加转义符的符号
    vn=[]#变量名
    vc=[]#变量内容
    iv=['_varcheck','_time']#内部变量
    i=0
    j=0
    list=[]
    class block:
        def __init__(self):#初始化
            self.a=0
            self.b=''
            self.c=[]
            self.d=[]
        def get_n(self,text):#获取函数名
            return text[0:text.index('(')]#返回结果
        def get_c(self,text):#获取隔开的内容，如'a'+'b'就会返回'a'和'b'
            self.a=0
            self.b=''
            self.c=[]
            self.d=[]
            while self.a<len(text):#重复执行直到a大于text字符数
                if text[self.a] not in no:#检测是否是需要转义符的字符
                    self.b=self.b+text[self.a]
                    self.a+=1
                else:
                    if text[self.a-1]=='#':#检测前面是否有转义符
                        #由于这时self.b已经把转义符添加进去了，所以需要去除
                        #这时需要转义符的字符已经有转义符了，所以需要加上这个字符
                        self.b=self.b[0:len(self.b)-1]+text[self.a]
                        self.a+=1#这一步很重要，否则下次循环时self.a指定的还是需要转义的字符，造成死循环
                    else:
                        self.c.append(self.b)
                        self.b=''
                        self.a+=1
            self.c.append(self.b)#由于self.a超过就结束了，所以最后一项内容没来得及添加，故这里添加
            return self.c
        def pocket(self,text):
            if text[0]+text[len(text)-1]=="''" or text[0]+text[len(text)-1]=='""':#检测两边是否有引号
                #字符串
                return text[1:len(text)-1]
            elif text in vn or text in iv:
                if text[0]=='_':
                    if text=='_varcheck':
                        return '变量名:'+str(vn)+'\n变量内容：'+str(vc)
                    elif text=='_time':
                        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                else:
                    return vc[vn.index(text)]
            elif sl.isnumber(text)==True:
                return text
            elif '(' in text and ')' in text:
                return self.function(self.get_n(text),text) 
        def isnumber(self,s):
            try:
                int(s)
                return True
            except ValueError:
                pass  
            try:
                float(s)
                return True
            except ValueError:
                pass
            return False
        def function(self,name,code):
            if name=='text':
                list=sl.get_c(code[code.index('(')+1:code.index(')',-1)])
                for t in list:
                    print(sl.pocket(t),end='')
                print()
            elif name=='var':
                #var定义时直接pocket变量内容并保存
                list=sl.get_c(code[code.index('(')+1:code.index(')',-1)])
                if len(list[0])>0 and list[0][0]!='_' and sl.isnumber(list[0])==False:#变量名第一个字符不能是'_',不能纯数字
                    if list[0] in vn:#检测是否已定义变量
                        j=list[0]#备份变量名
                        i=''
                        for x in list[1:len(list)]:#list的第二项后都是变量内容，这里整理起来给下面get_c用
                            i=i+x+'+'
                        i=i[0:len(i)-1]
                        list=sl.get_c(i)
                        i=''
                        for a in list:
                            i=i+sl.pocket(a)
                        vc[vn.index(j)]=i
                    else:
                        vn.append(list[0])
                        i=''
                        for x in list[1:len(list)]:#list的第二项后都是变量内容，这里整理起来给下面get_c用
                            for y in x:
                                if y in no:#第一次get_c时把转义符去掉了，这里添加上去，不然下面的get_c会错误
                                    i=i+'#'+y
                                else:
                                    i=i+y
                            i=i+'+'
                        i=i[0:len(i)-1]
                        list=sl.get_c(i)
                        i=''
                        for a in list:
                            i=i+sl.pocket(a)
                        vc.append(i)
            elif name=='get':
                list=sl.get_c(code[code.index('(')+1:code.index(')',-1)])
                debug(list)
                i=''
                for t in list:
                    i=i+sl.pocket(t)
                return input(i)
    sl=block()
    #获取代码
    file_name=input('请输入代码文件的文件名：')+'.sl'
    if os.path.isfile(file_name)==True:
        print('代码获取中...')
        file=open(file_name,'r')
        i=file.readlines()#将内容转换为列表
        i[len(i)-1]=i[len(i)-1]+'\n'#给最后一个添加上\n
    else:
        print('未检测到文件，有没有可能是多加了后缀（.sl）？')
        return 114514#这是个彩蛋！但是它臭掉了!/首/
    #代码解压
    print('代码解压中...')
    for x in i:#去掉\n
        i[i.index(x)]=x[0:len(x)-1]
    print('解压后的代码为：')

    #输出代码
    print('')
    for c in i:
        print(c)
    print()

    #运行
    print('////////开始运行////////\n')
    for code in i:
        fn=sl.get_n(code)#fn=function name
        sl.function(fn,code)
    print('\n////////运行结束////////')
while True:
    for i in range(20):
        print('-',end='')
    print()
    ans=input('1.运行程序 2.退出：')
    if ans=='1':
        runone()
    elif ans=='2':
        break