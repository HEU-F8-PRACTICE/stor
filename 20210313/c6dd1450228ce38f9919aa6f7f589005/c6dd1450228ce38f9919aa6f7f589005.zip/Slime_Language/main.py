'''
v0.2.2(2020.3.11~2021.3.13)
添加了内部变量_funccheck
添加了def自定义函数
修复了若干bug
添加了import
'''
def debug(text):#用于调试
    print('debug['+str(text)+"]")
#初始化
import os,time,math
print('初始化中...') 
if os.path.exists('slime-import')==False:
    os.system('mkdir slime-import')
    file=open("slime-import/readme.md","w")
    file.write("# 将slime库文件放在此处")
    file.close()
    print("//文件夹丢失，已自动添加//")
while True:
    fnl=['text','var','len','type','get','pass','isnum','!']
    no=['+',',','-','*','/','%']#需要加转义符的符号
    vn=[]#变量名
    vc=[]#变量内容
    bvc=[]#变量内容（未pocket）
    ifn=[]#自定义函数
    ifc=[]#自定义函数的代码
    ifi=[]#自定义函数的输入项
    iv=['_varcheck','_time','_funccheck']#内部变量
    i=0
    j=0
    jump=0
    list=[]
    l=[]
    class block:
        def __init__(self):#初始化
            self.a=0
            self.b=''
            self.c=[]
            self.d=[]
        def get_n(self,text):#获取函数名
            if '(' in text and ')' in text:
                if text.find(')')>text.find('('):
                    return text[0:text.find('(')]#返回结果
        def get_z(self,text):#获取内容中的特殊符号
            self.c=[]
            for x in text:
                if x in no and text[text.find(x)-1]!='#':
                    self.c.append(x)
            return self.c
        def get_c(self,text):#获取隔开的内容，如'a'+'b'就会返回'a'和'b'
            self.a=0
            self.b=''
            self.c=[]
            self.d=[]
            while self.a<len(text):#重复执行直到a大于text字符数
                if text[self.a] not in no:#检测是否是需要转义符的字符
                    self.b=self.b+text[self.a]
                    self.a+=1
                else:
                    if text[self.a-1]=='#':#检测前面是否有转义符
                        #由于这时self.b已经把转义符添加进去了，所以需要去除
                        #这时需要转义符的字符已经有转义符了，所以需要加上这个字符
                        self.b=self.b[0:len(self.b)-1]+text[self.a]
                        self.a+=1#这一步很重要，否则下次循环时self.a指定的还是需要转义的字符，造成死循环
                    else:
                        if sl.isnumber(self.b)==True:
                            self.c.append(sl.tonum(self.b))
                        else:
                            self.c.append(self.b)
                        self.b=''
                        self.a+=1
            if sl.isnumber(self.b)==True:
                self.c.append(sl.tonum(self.b))
            else:
                self.c.append(self.b)
#由于self.a超过就结束了，所以最后一项内容没来得及添加，故这里添加
            return self.c
        def get_f(self,text):
            self.c=[]
            for x in text:
                if x in no and text[text.find(x)-1]!='#':
                    self.c.append(x)
            return self.c
        def get_i(self,code):
            global i
            i=code[code.find('(')+1:code.rfind(')')]
            l=sl.get_z(i)
            list=sl.get_c(i)
            if len(list)>1:
                i=sl.pocket(list[0])
                del list[0]  
                for t in range(len(list)): 
                    if l[t]=='+':
                        i=i+sl.pocket(list[t])
                    elif l[t]==',':
                        if i!="" and i!=None:
                            i=str(i)
                            i=i+"|"+str(sl.pocket(list[t]))
                        else:
                            i=i+str(sl.pocket(list[t]))
                    elif l[t]=='-':
                        i=i-sl.pocket(list[t])
                    elif l[t]=='*':
                        i=i*sl.pocket(list[t])
                    elif l[t]=='/':
                        i=i/sl.pocket(list[t])
                    elif l[t]=='%':
                        i=i%sl.pocket(list[t])
            else:
                i=sl.pocket(list[0])
            return i
        def iv(self,text):
            if text=='_varcheck':
                return '变量名:'+str(vn)+'\n变量内容：'+str(vc)+'\n原变量内容：'+str(bvc)
            elif text=='_time':
                return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            elif text=='_funccheck':
                return '函数名：'+str(ifn)+'\n函数代码：'+str(ifc)+'\n函数输入项：'+str(ifi)
        def tonum(self,text):
            j=sl.num_type(text)
            if j=="int":
                return int(text)
            elif j=="flaot":
                return float(text)
            return text
        def pocket(self,text):
            if text!=None and text!="":
                if sl.isnumber(text)==True:
                    return text
                elif text[0]+text[len(text)-1]=="''" or text[0]+text[len(text)-1]=='""':#检测两边是否有引号
                    #字符串
                    return text[1:len(text)-1]
                elif text in vn or text in iv:
                    if text[0]=='_':
                        return sl.iv(text)
                    else:
                        return vc[vn.index(text)]
                elif '(' in text and ')' in text:
                    return sl.pocket(self.function(self.get_n(text),text)) 
                else:
                    return text
            else:
                return ""
        def p_type(self,text):
            if sl.isnumber(text)==True:
                return sl.num_type(text)
            elif text[0]+text[len(text)-1]=="''" or text[0]+text[len(text)-1]=='""':#检测两边是否有引号
                #字符串
                return 'str'
            elif text in vn or text in iv:                  
                if text[0]=='_':
                    return '_var'
                else:
                    return 'var'
            elif '(' in text and ')' in text:
                if sl.get_n(text) in fnl:
                    return sl.p_type(self.function(self.get_n(text),text))
            return 'NoneType'

        def isnumber(self,s):
            try:
                int(s)
                return True
            except ValueError:
                pass  
            try:
                float(s)
                return True
            except ValueError:
                pass
            return False
        def num_type(self,s):
            try:
                int(s)
                return 'int'
            except ValueError:
                pass  
            try:
                float(s)
                return 'float'
            except ValueError:
                pass
            return ''
        def function(self,name,code):
            if name=='text':
                print(sl.get_i(code))
            elif name=='var':
                global i
                #var定义时直接pocket变量内容并保存
                list=sl.get_c(code[code.find('(')+1:code.rfind(')')])
                if sl.isnumber(list[0])==False and len(list[0])>0 and list[0][0]!='_':#变量名第一个字符不能是'_',不能纯数字
                    if list[0] in vn:#检测是否已定义变量
                        j=list[0]#备份变量名
                        i=''
                        for b in list[1:]:
                            i=i+str(b)+","
                        i=i[:-1]
                        bvc[vn.index(j)]=i
                        vn.append(list[0])
                        i=""
                        for x in list[1:len(list)]:#list的第二项后都是变量内容，这里整理起来给下面get_c用
                            i=i+str(x)+'+'
                        i=i[0:len(i)-1]
                        vc[vn.index(j)]=sl.get_i("("+i+")")

                    else:
                        i=''
                        for b in list[1:]:
                            i=i+str(b)+","
                        i=i[:-1]
                        bvc.append(i)
                        vn.append(list[0])
                        i=""
                        for x in list[1:len(list)]:#list的第二项后都是变量内容，这里整理起来给下面get_c用
                            i=i+str(x)+'+'
                        i=i[0:len(i)-1]
                        vc.append(sl.get_i("("+i+")"))
                        
                else:
                    print('//NamingError:变量命名无效//')
            elif name=='get':
                return '"'+input(sl.get_i(code))+'"'
            elif name=='len':
                return len(sl.get_i(code))
            elif name=='type':
                list=sl.get_c(code[code.find('(')+1:code.rfind(')')])
                if list[0] in vn:
                    return '"[type:'+sl.p_type(bvc[vn.index(list[0])])+']"'
                else:
                    return '"[type:'+sl.p_type(list[0])+']"'
            elif name=='isnum':
                return sl.isnumber(sl.get_i(code))
            elif name=='pass':
                pass
            elif name=='!':
                pass
            elif name=='str':
                return str(sl.get_i(code))
            elif name=='int':
                return int(sl.get_i(code))
            elif name=='float':
                return float(sl.get_i(code))
            elif code[code.find("d"):code.find("f")+2]=="def ":
                i=0
                global jump
                while code[i]==" ":
                    i+=1
                if i%4==0:
                    i=i/4+1
                    j=0
                    list=[]
                    for s in script[script.index(code)+1:]:
                        j=0
                        self.a=s
                        while self.a[j]==" ":
                            j+=1
                        j=j/4
                        if j!=i:break
                        j=0
                        while self.a[j]==" ":
                            j+=1
                        list.append(self.a[j:])
                        j=j/4
                    i=code
                    j=0
                    while i[j]==" ":
                        i=i[:1]
                        j+=1
                    if i[-1]==":" and "(" in i and ")" in i:
                        if i[i.index(" ")+1:i.index("(")] not in fnl:
                            ifn.append(i[i.index(" ")+1:i.index("(")])
                            fnl.append(ifn[-1])
                            ifi.append(i[i.index("(")+1:i.index(")")].split(","))
                            ifc.append(list)
                            jump=len(ifc[-1])
                        else:
                            j=ifn.index(i[i.index(" ")+1:i.index("(")])
                            ifc[j]=list
                            ifi[j]=i[i.index("(")+1:i.index(")")].split(",")
                            jump=len(ifc[j])
                    else:
                        print('//DefError//')
                    
                else:
                    print("//IndentError:缺少缩进块或无效缩进块//")
            elif code[code.find("i"):code.find("t")+2]=="import ":
                list=code[code.index(" ")+1:].split(",")
                for n in list:
                    sl.a=os.getcwd()+"/slime-import/"+n+".sli"
                    if os.path.isfile(sl.a)==True:
                        file=open(sl.a,'r')
                        sl.c=file.readlines()#将内容转换为列表
                        sl.c[-1]=sl.c[-1]+'\n'#给最后一个添加上\n
                        for x in sl.c:#去掉\n
                            j=sl.c.index(x)
                            sl.c[j]=x[0:len(x)-1]
                            i=sl.c[j]
                            while i[-1]==' ':
                                i=i[0:-1]
                            sl.c[j]=i
                        if sl.c[0]=="/!import/":
                            del sl.c[0]
                            sl.d=script[:script.index(code)]+sl.c+script[script.index(code)+1:]
                            for y in range(len(script)):
                                del script[0]
                            for t in sl.d:
                                script.append(t)
                        else:
                            print("ImportError:")
                    else:
                        print("ImportError:未找到文件")
            elif name in ifn:
                j=ifn.index(name)
                list=code[code.find("(")+1:code.rfind(")")].split(",")
                if len(list)==len(ifi[j]):
                    for x in ifi[j]:
                        vn.append(name+"."+x)
                        vc.append(sl.get_i("("+str(list[ifi[j].index(x)])+")"))
                        bvc.append(list[ifi[j].index(x)])
                    list=[]
                    for s in ifc[j]:
                        sl.function(sl.get_n(s),s)
                    list=[]
                    for l in vn:
                        list.append(l)
                    for v in list:
                        if v[:len(name+".")]==name+".":
                            i=vn.index(v)
                            del vn[i]
                            del vc[i]
                            del bvc[i]
                else:
                    print("//InputError:输入项不匹配//")
            else:
                print('//NameError:无效函数"'+code+'"//')
    sl=block()
    ans=input('1.运行程序 2.交互式 3.退出：')
    if ans=='1':
        #获取代码
        file_name=input('请输入代码文件的文件名：')+'.sl'
        if os.path.isfile(file_name)==True:
            print('代码获取中...')
            file=open(file_name,'r')
            script=file.readlines()#将内容转换为列表
            script[len(script)-1]=script[len(script)-1]+'\n'#给最后一个添加上\n
            #代码解压
            print('代码解压中...')
            for x in script:#去掉\n
                j=script.index(x)
                script[j]=x[0:len(x)-1]
                i=script[j]
                while i[-1]==' ':
                    i=i[0:-1]
                script[j]=i
            print('解压后的代码为：')
            #输出代码
            print('')
            for c in script:
                print(c)
            print()

            #运行
            print('////////开始运行////////\n')
            for code in script:
                fn=sl.get_n(code)#fn=function name
                if jump==0:
                    sl.function(fn,code)
                else:
                    jump-=1
            print('\n////////运行结束////////')
        else:
            print('未检测到文件，有没有可能是多加了后缀（.sl）？')
        
    elif ans=='2':
        while True:
            script=[input('€ ')]
            if script[0]=='quit()':
                break
            elif script[0] in vn:
                print(vc[vn.index(script[0])])
            elif script[0] in iv:
                print(sl.iv(script[0]))
            elif script[0]=='':
                pass
            else:
                i=script[0]
                while i[-1]==" ":
                    i=i[0:-1]
                fn=sl.get_n(i)
                backtext=sl.function(fn,i)
                if backtext!=None:
                    print(sl.pocket(backtext))
    elif ans=='3':
        break
    else:
        print('指令无效')
