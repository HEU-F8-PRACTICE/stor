#v0.0.6(2020.2.19~2021.2.20)
def runone():
    #初始化
    print('初始化中...')
    import os
    class block:
        def __init__(self):#对象初始化
            self.a=0
            self.b=''
            self.cl=[]#c list可使用的列表
            self.dl=[]#d list可使用的列表
            self.el=[]#e list运行时使用的列表
            self.fl=[]#f list运行时使用的列表
            self.back=''#返回的变量
            self.blist=[]#back list返回的列表
            self.vn=['_varcheck']#var name程序里的变量名
            self.vt=['']#var text程序里的变量内容
            self.error=[]#返回是否错误
        def get_name(self,text):#获取函数名
            self.back=text[0:text.index('(')]
        def get_c(self,text):#获取括号内内容
            self.a=text.index('(')+1
            self.b=''
            self.blist=[]
            while True:
                if self.a<len(text) and text[self.a-1]!=')':
                    while self.a<len(text):
                        if text[self.a]==')':
                            break
                        elif text[self.a]=='+':
                            if text[self.a-1]!='#':
                                break
                            else:
                                self.delend(self.b,1)
                                self.b=self.back
                        self.b=self.b+str(text[self.a])
                        self.a+=1
                    self.blist.append(self.b)
                    self.b=''
                    self.a+=1
                else:
                    break
        def pocket(self,text):#检测内容
            self.blist=[]
            self.back=''
            
            #非字符串
            if text[0]+text[len(text)-1]!="''" and text[0]+text[len(text)-1]!='""':
                if ',' in text:
                    self.a=0
                    self.b=''
                    for x in range(len(text)):
                        if text[self.a]==',':
                            if text[self.a-1]!='#':
                                self.blist.append(self.b)
                                self.b=''
                                self.a+=1
                            else:
                                self.delend(self.b,1)
                                self.b=self.back+','
                                self.a+=1
                        else:
                            self.b=self.b+text[self.a]
                            self.a+=1
                    self.blist.append(self.b)
                    return 1
                elif text in self.vn:
                    if text[0]=='_':#内置变量
                        if text=='_varcheck':
                            self.blist=[]
                            self.cl=[]
                            self.dl=[]
                            for x in self.vn:
                                if x[0]!='_':
                                    self.cl.append(x)
                                    self.dl.append(self.vt[self.vn.index(x)])
                            self.blist.append('var_name:'+str(self.cl))
                            self.blist.append('\nvar_text:'+str(self.dl))
                            self.error=['0','0']
                            return 1
                    else:
                        self.cl=[]
                        self.get_c('('+self.vt[self.vn.index(text)]+')')
                        #print('!',self.vt[self.vn.index(text)])
                        for p in self.blist:
                            self.pocket(p)
                            self.cl.append(self.blist[-1])
                        for x in self.cl:
                            self.blist.append(x)
                        return 1
            #文本
            if text[0]=="'":
                if text[len(text)-1]!="'":
                    self.error.append('1')
                    print('//字符缺失：缺少引号2('+text+')//')
                else:
                    self.blist.append(text[1:len(text)-1])
                    self.error.append('0')
                    return 1
            elif text[0]=='"':
                if text[len(text)-1]!='"':
                    self.error.append('1')
                    print('//字符缺失：缺少引号2('+text+')//')
                else:
                    self.blist.append(text[1:len(text)-1])
                    self.error.append('0')
                    return 1            
            if text[len(text)-1]=="'":
                if text[0]!="'":
                    self.error.append('1')
                    print('//字符缺失：缺少引号1('+text+')//')
            elif text[len(text)-1]=='"':
                if text[0]!='"':
                    self.error.append('1')
                    print('//字符缺失：缺少引号1('+text+')//')
            
        def delend(self,text,num):
            self.back=text[0:len(text)-num]
    sl=block()
    
    #获取代码
    file_name=input('请输入代码文件的文件名：')+'.sl'
    if os.path.isfile(file_name)==True:
        print('代码获取中...')
        file=open(file_name,'r')
        i=file.readlines()#将内容转换为列表
        i[len(i)-1]=i[len(i)-1]+'\n'#给最后一个添加上\n
    else:
        print('未检测到文件，有没有可能是多加了后缀（.sl）？')
        return 114514#这是个彩蛋！但是它臭掉了!/首/
    #代码解压
    print('代码解压中...')
    for x in i:#去掉\n
        i[i.index(x)]=x[0:len(x)-1]
    print('解压后的代码为：')

    #输出代码
    print('')
    for c in i:
        print(c)
    print()

    #运行
    print('////////开始运行////////\n')
    for script in i:
        sl.get_name(script)
        if sl.back=='text':
            sl.error=[]
            sl.get_c(script)
            sl.el=[]
            sl.fl=[]
            for x in sl.blist:
                sl.el.append(x)
            for p in sl.el:
                sl.pocket(p)
                #print('!',p,sl.blist)
                for l in sl.blist:
                    sl.fl.append(l)
            #print('!',sl.error,sl.fl)
            for v in sl.fl:
                if sl.error[sl.fl.index(v)]!='1':#防止发生错误还打印
                    print(v,end='')
            print('')
        elif sl.back=='!':
            pass
        elif sl.back=='var':
            sl.pocket(script[script.index('(')+1:len(script)-1])
            if sl.blist[0][0]!='_':
                if sl.blist[0] not in sl.vn:
                    sl.vn.append(sl.blist[0])
                    sl.vt.append(sl.blist[1])       
                else:
                    sl.vt[sl.vn.index(sl.blist[0])]=sl.blist[1]     
    print('\n////////运行结束////////')
while True:
    for i in range(20):
        print('-',end='')
    print()
    ans=input('1.运行程序 2.退出：')
    if ans=='1':
        runone()
    elif ans=='2':
        break