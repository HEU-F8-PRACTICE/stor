如何使用slime？
1.把代码文件放在slime文件同目录下（文件后缀为.sl）
2.运行slime文件
3.输入1
4.输入文件名（后缀不用）
5.运行啦！

slime代码示例：
var(a,'hello world!')
text(a)

已知bug：
var(a,'a')
var(b,a)
text(a+b)
会出现bug，如果你找到了解决办法，请联系我吧！（qq：181275358）