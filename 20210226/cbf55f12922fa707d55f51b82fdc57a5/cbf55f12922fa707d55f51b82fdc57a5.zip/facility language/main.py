# facility从2021-02-20 22:50开始编写
# 作者Fatasying
# 当前版本：Alpha v0.0.1(2021-02-20~2020-02-26)
# 新增功能：可用output()函数输出字符串

def debug(sth):  # 调试，用于输出列表、变量的值
    print('debug:' + str(sth))

class Facility:
    def __init__(self, file):
        self.file = file + '.fy'  # 获取文件名+后缀
        self.VariableName = []  # 变量名
        self.VariableValue = []  # 变量内容
        self.CodeDu = []  # 使用者写的程序(读取)
        self.Code = [] # 使用者写的程序(去除\n)
        self.FunctionName = [] # 每行代码使用的函数的名称
        self.FunctionValue = [] # 每行代码使用的函数的参数
        self.FVType = [] # 每行代码使用的函数的参数的种类
        self.FileFound = False  # 文件检测初始化为False
        self.FVTIsNum = '123456789' # 函数参数种类是否为数字
        self.i = 0  # 初始化自由变量
        self.j = ''
        self.k = ''

    def FoundFile(self):  # 此为文件检测函数
        try:  # 尝试打开文件
            with open(self.file, 'r') as file:  # 读文件
                self.CodeDu = file.readlines()  # 将程序写入self.Code
                self.FileFound = True
            print('\nThe file \"%s\" is found.' % self.file)
        except FileNotFoundError:  # 当文件不存在时运行下面的代码
            print('\nThe file \"%s\" is NOT found /!WORRY!/' % self.file)
            self.FileFound = False

    def GetFunctionInformation(self):
        self.i = 0  # 自由变量
        self.j = ''
        for self.i in range(0, len(self.Code)):
            for self.j in self.Code[self.i]:
                if self.j == '(':
                    self.FunctionName.append(self.k)
                    self.k = ''
                elif self.j == ')': # [需要修改]记得字符串在加入FunctionValue列表时要去掉''或者""
                    if (self.k[0] == "'" or self.k[0] == '"') and (self.k[len(self.k) - 1] == '"' or self.k[len(self.k) - 1] == "'"):
                        self.FunctionValue.append(self.k[1:len(self.k) - 1])
                        self.FVType.append('str')
                    else: # [需要修改]记得还有“数字”，“变量”等参数类型
                        pass
                    self.k = ''
                else:
                    self.k = self.k + self.j

    def Function(self,FName,FValue):
        if FName == 'output':
            if self.FVType[self.FunctionValue.index(FValue)] == 'str':
                print(FValue)
            else: # 其他函数在这上面加
                pass

    def Run(self):
        print('\nThe code :')
        for self.CodeValue in self.CodeDu:  # 分行输出程序
            self.Code.append(self.CodeValue.rstrip('\n'))
            print('\t'+self.CodeValue.rstrip('\n'))
        self.GetFunctionInformation() # 获取使用者使用的函数信息
        print('\nThe running results :')
        self.i = 0  # 自由变量
        while self.i < len(self.FunctionName):
            self.Function(self.FunctionName[self.i],self.FunctionValue[self.i])
            self.i += 1


print('----facility run----')

while True:
    print('\n--------------------')
    answer = input('What would you do:\n1.run code\n2.exit\n')
    if answer == '1':
        FileFound = False
        while FileFound == False:
            file = input(
                'Please input the name of the file(Don\'t need the \".fy\"):')
            Frun = Facility(file)  # 创建运行对象
            Frun.FoundFile()  # 寻找文件
            FileFound = Frun.FileFound
        Frun.Run()  # 运行
    elif answer == '2':
        break
    else:
        print('\nFacility can\'t understand you!')

print('\n----facility over----')
