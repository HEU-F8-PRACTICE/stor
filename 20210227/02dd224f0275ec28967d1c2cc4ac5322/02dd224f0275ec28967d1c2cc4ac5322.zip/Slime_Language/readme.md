# 如何使用slime？  
## 文件运行  
1.把代码文件放在slime文件同目录下（文件后缀为.sl）  
2.使用python运行slime文件  
3.输入1  
4.输入文件名（后缀不用）  
5.运行啦！  
## 交互式
1.使用python运行slime文件
2.输入2
3.好啦！


# slime代码示例：  
var(a,'hello world!')  
text(a)  
text('现在是'+_time)  
var(a,get('输入一些文字：'))  
text('你输入了：'+a)  
get('回车退出')  

